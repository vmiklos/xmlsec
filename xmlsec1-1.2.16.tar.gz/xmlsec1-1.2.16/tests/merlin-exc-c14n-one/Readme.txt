untested exclusive c14n example signature + c14n output
merlin@baltimore.ie
mon jan 14 2002
